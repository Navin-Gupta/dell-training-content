import React from 'react';
import { BrowserRouter, Link, NavLink, Route, Switch } from 'react-router-dom';
import About from './About';
import CommentBox from './CommentBox';
import Contact from './Contact';
import Home from './Home';
import NotFound from './NotFound';
import Search from './Search';
import './App.css';
import Counter from './Counter';

class App extends React.Component{

    _search(event){
        event.preventDefault();
        if(this._searchText.value !== ""){
            // props contain an inbuilt object : history
            // this.props.history.push("/");
            // eslint-disable-next-line no-restricted-globals
            // history.push("/search");
            
        }
    }

    render(){
        return(
            <BrowserRouter>
                <div>
                    <ul className="nav nav-pill nav-justified">
                        <li className="nav-item">
                            {/* to="" asks for url mapped with component */}
                            <NavLink activeClassName="active" className="nav-link btn-primary" to="/">HOME</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink activeClassName="active" className="nav-link btn-primary" to="/aboutus">ABOUT</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink activeClassName="active" className="nav-link btn-primary" to="/contact">CONTACT</NavLink>
                        </li>
                        <li className="nav-item">
                            <NavLink activeClassName="active" className="nav-link btn-primary" to="/counter">COUNTER</NavLink>
                        </li>
                        <li className="nav-item">
                            <span className="nav-link btn-primary">BLOGS</span>
                            <ul>
                                <li><Link  className="nav-link btn-primary" to="/blog/1">Blog - 1</Link></li>
                                <li><Link  className="nav-link btn-primary" to="/blog/2">Blog - 2</Link></li>
                                <li><Link  className="nav-link btn-primary" to="/blog/3">Blog - 3</Link></li>
                            </ul>
                        </li>
                    </ul>
                    <hr/>
                    <form onSubmit={this._search.bind(this)} >
                        <input placeholder="Search here..." 
                            ref={(input)=>this._searchText = input}/>                                                          
                        <button type="submit">Search</button>
                </form>
                    <hr/>
                    {/* Define the routes : mapping url with component */}
                    <Switch>
                        <Route exact path="/" component={Home} />
                        <Route path="/aboutus" component={About} />
                        <Route path="/contact" component={Contact} />
                        <Route path="/counter" component={Counter} />
                        <Route path="/search" component={Search} />
                        <Route path="/blog/:id" component={CommentBox} />
                        <Route component={NotFound} />
                    </Switch>
                </div>
            </BrowserRouter>
        );
    }
}

export default App;