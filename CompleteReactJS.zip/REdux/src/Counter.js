import React from 'react';
import { connect } from 'react-redux';

class Counter extends React.Component{

    // custom method to handle inc/dec
    _handleIncrement(){
        this.props.dispatch({
            type : "INCREMENT",
            step : 5
        });
    }

    _handleDecrement(){
        this.props.dispatch({
            type : "DECREMENT",
            step : 3
        });
    }

    render(){
        return(
            <div>
                <h1>This is Counter Page!</h1>
                <div>
                    <button className="btn btn-primary" 
                            onClick={this._handleIncrement.bind(this)}>Increment(+)</button>
                    <hr/>
                        <span>{this.props.count}</span>
                    <hr/>
                    <button className="btn btn-warning" 
                            onClick={this._handleDecrement.bind(this)}>Decrement(-)</button>
                </div>
            </div>
        );
    }
}

// function : logic to describe what part of store to consume
// mapping of store to props : store data will be exposed a props

function mapStoreToProp(store){
    // return a new object , containing the part of store
    return {
        count : store.count
    }
}



// connect the component with store
// connect(<function: mapping logic>)(<component : in which to inject the prop>)
// fun = connect(mapStoreToProp);
// var counter_new = fun(Counter);
// return updated version of Counter/Component
// export default counter_new;
export default connect(mapStoreToProp)(Counter);


// export default Counter;