import React from 'react';

class Search extends React.Component{

    render(){
        return(
            <div>
                <h1>This is Search Page!</h1>
            </div>
        );
    }
}

export default Search;