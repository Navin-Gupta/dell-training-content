import { createStore } from "redux";

// create a reducer
// must return the state of redux store : what store will contain
/*function reducer(){
    return {
        // key : value
        count : 10,
        test : "ReactJS"
    }
}*/

// initial state of the store
const initialState = {
    count : 10,
    test : "React"
} 




// auto recieves the object sent using dispatch by component
// reducer is also passed with current state of store
// method must always return final/changed state of store
function reducer(store = initialState, action){
    console.log(store);
    console.log(action);
    switch(action.type){
        case "INCREMENT" : 
                // store.count++;
                return {
                    count : store.count + action.step
                }
                
        case "DECREMENT" : 
                return {
                    // count : store.count - 1
                    count : store.count - action.step
                }
        default : return store;
    }
    return store;
    
}

// create a store
const store = createStore(reducer);

export default store;