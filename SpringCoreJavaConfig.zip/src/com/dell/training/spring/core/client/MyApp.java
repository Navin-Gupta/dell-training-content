package com.dell.training.spring.core.client;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dell.training.spring.core.config.MyConfig;
import com.dell.training.spring.core.service.EmailService;
import com.dell.training.spring.core.service.IMessagingService;

public class MyApp {

	public static void main(String[] args) {
		// initiate the bean factory
		AnnotationConfigApplicationContext context =
				new AnnotationConfigApplicationContext(MyConfig.class);
		
		// fetch the object
		IMessagingService service = context.getBean("emailService", IMessagingService.class);
		String ack = service.sendMessage("someone", "Hello there...");
		System.out.println(ack);
		
		
		
		// closing the bean factory
		context.close();
		
	}

}
