package com.dell.training.spring.core.config;

import java.time.LocalTime;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.dell.training.spring.core.service.IFortuneService;
import com.dell.training.spring.core.service.PersonalFortune;
import com.dell.training.spring.core.service.ProfessionalFortune;

// Treat it as config : allow you to use it as config file
@Configuration
// Component scanning path
@ComponentScan("com.dell.training.spring.core")
// refer to property file
@PropertySource("classpath:sender-info.properties")
public class MyConfig {
	// add a logic to decide which Fortune Service to expose
	// define a method to hold the logic
	// Want Bean Factory to call the method and use the return value as a bean
	@Bean
	public IFortuneService fortuneService() {
		if(LocalTime.now().getHour() < 10 ||LocalTime.now().getHour() > 17) {
			return new PersonalFortune();
		}
		return new ProfessionalFortune();
	}
}
