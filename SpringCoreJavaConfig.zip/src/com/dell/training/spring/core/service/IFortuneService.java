package com.dell.training.spring.core.service;

public interface IFortuneService {
	public String dailyFortune();
}
