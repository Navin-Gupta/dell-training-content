package com.dell.training.spring.core.service;

public class EmailService implements IMessagingService {

	// add dependency
	private IFortuneService fortuneService;
	private String sender;
	
	private static int instances;
	static {
		instances = 0;
	}
	
	public EmailService() {
		System.out.println("\n**********Email Object Created*******");
		EmailService.instances++;
	}
	
	/********Constructor based DI***********/
	/*public EmailService(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}*/
	
	/********* Setter DI *****************/
	public void setFortuneService(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}
	
	public void setSender(String sender) {
		this.sender = sender;
	}
	
	
	// custom init method
	public void customInit() {
		System.out.println("\n********Custom Init*******\n");
	}
	
	
	@Override
	public String sendMessage(String to, String message) {
		return "Email(" + EmailService.instances + ") sent to : " + to + "[" + message + "]" +
				"\nSent By : " + this.sender +
				"\n" + this.fortuneService.dailyFortune();
	}

	
	// custom destroy method
	public void customDestroy() {
		System.out.println("\n********Custom Destroy*******\n");
	}
}
