package com.dell.training.spring.core.service;

public interface IMessagingService {
	public String sendMessage(String to, String message);
}
