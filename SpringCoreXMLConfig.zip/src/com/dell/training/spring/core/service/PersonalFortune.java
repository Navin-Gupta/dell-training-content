package com.dell.training.spring.core.service;

public class PersonalFortune implements IFortuneService {

	@Override
	public String dailyFortune() {
		return "Today is your lucky day!";
	}

}
