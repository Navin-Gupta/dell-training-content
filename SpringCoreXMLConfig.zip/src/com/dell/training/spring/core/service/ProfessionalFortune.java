package com.dell.training.spring.core.service;

public class ProfessionalFortune implements IFortuneService {

	@Override
	public String dailyFortune() {
		return "Today your Team Lead is on leave...";
	}

}
