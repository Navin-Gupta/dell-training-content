package com.dell.training.spring.core.service;

public class SmsService implements IMessagingService {

	@Override
	public String sendMessage(String to, String message) {
		return "SMS sent to : " + to + "[" + message + "]";
	}

}
