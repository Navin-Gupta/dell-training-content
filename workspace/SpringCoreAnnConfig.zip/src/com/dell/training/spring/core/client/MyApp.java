package com.dell.training.spring.core.client;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.dell.training.spring.core.service.EmailService;
import com.dell.training.spring.core.service.IMessagingService;

public class MyApp {

	public static void main(String[] args) {
		// initiate the bean factory
		ClassPathXmlApplicationContext context =
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// fetch the object
		IMessagingService service = context.getBean("emailService", IMessagingService.class);
		String ack = service.sendMessage("someone", "Hello there...");
		System.out.println(ack);
		
		
		
		// closing the bean factory
		context.close();
		
	}

}
