package com.dell.training.spring.core.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

// @Component("msgService")
@Component // Class name will become id with first character in small case
@Scope("singleton")
public class EmailService implements IMessagingService {

	// add dependency
	// @Autowired
	// @Qualifier("personalFortune")
	private IFortuneService fortuneService;
	
	@Value("${mail.sender}")
	private String sender;
	
	
	
	// constructor based
	@Autowired //  : not mandatory 
	public EmailService(@Qualifier("professionalFortune")IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}
	
	// Setter/method based DI
	/*@Autowired
	@Qualifier("personalFortune")
	public void xyz(IFortuneService fortuneService) {
		this.fortuneService = fortuneService;
	}*/
	
	@PostConstruct
	public void customInit() {
		System.out.println("\n******Custom Init********\n");
	}
	
	@Override
	public String sendMessage(String to, String message) {
		return "Email sent to : " + to + "[" + message + "]" +
				"\nSent By : " + this.sender +
				"\n" + this.fortuneService.dailyFortune();
				
	}
	
	@PreDestroy
	public void customDestroy() {
		System.out.println("\n******Custom Destroy********\n");
	}

}
