package com.dell.training.spring.core.service;

import org.springframework.stereotype.Component;

@Component
public class PersonalFortune implements IFortuneService {

	@Override
	public String dailyFortune() {
		return "Today is your lucky day!";
	}

}
