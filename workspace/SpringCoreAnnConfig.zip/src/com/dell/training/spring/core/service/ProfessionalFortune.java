package com.dell.training.spring.core.service;

import org.springframework.stereotype.Component;

@Component
public class ProfessionalFortune implements IFortuneService {

	@Override
	public String dailyFortune() {
		return "Today your Team Lead is on leave...";
	}

}
