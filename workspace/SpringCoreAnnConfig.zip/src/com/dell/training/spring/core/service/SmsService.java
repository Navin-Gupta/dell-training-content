package com.dell.training.spring.core.service;

import org.springframework.stereotype.Component;

// @Component("msgService")
@Component
public class SmsService implements IMessagingService {

	@Override
	public String sendMessage(String to, String message) {
		return "SMS sent to : " + to + "[" + message + "]";
	}

}
